from __future__ import annotations

from pathlib import Path
import json
import shutil
import struct
import sys
import zlib

import bpy
import numpy as np
from mathutils import Color

from .constants import TEXTURE_SLOTS
from .nodes import (
    find_material_group_node,
    find_texture_node,
    is_mw_material,
)


class CS2ExportError(RuntimeError):
    pass


def _safe_asset_name(name: str) -> str:
    cleaned = name.strip()
    if cleaned.lower().endswith(".fbx"):
        cleaned = cleaned[:-4]
    for character in '<>:"/\\|?*':
        cleaned = cleaned.replace(character, "_")
    return cleaned.strip(". ")


def _slot_pixels(material, slot, width, height):
    texture_node = find_texture_node(material, slot)
    image = texture_node.image if texture_node is not None else None
    if image is None:
        default = np.asarray(_EXPORT_DEFAULTS.get(slot, TEXTURE_SLOTS[slot]["default"]), dtype=np.float32)
        return np.broadcast_to(default, (width * height, 4)).copy()

    if tuple(image.size) != (width, height):
        raise CS2ExportError(
            f"{TEXTURE_SLOTS[slot]['label']} must be {width}×{height} to match BaseColor. "
            "Textures are never resized"
        )

    if len(image.pixels) != width * height * 4:
        raise CS2ExportError(f"Cannot read RGBA pixels from {image.name}")
    pixels = np.empty(width * height * 4, dtype=np.float32)
    image.pixels.foreach_get(pixels)
    pixels = pixels.reshape((-1, 4))
    # Blender exposes byte images as encoded samples and float colour
    # buffers in the working space. Alpha and data slots stay linear.
    if image.is_float and slot in {"BASE_COLOR", "EMISSION"}:
        rgb = pixels[:, :3]
        if (image.source != "GENERATED" and not image.colorspace_settings.is_data
                and image.alpha_mode in {"STRAIGHT", "PREMUL"}):
            alpha = pixels[:, 3:4]
            np.divide(rgb, alpha, out=rgb, where=alpha > 0)
        _encode_float_color(rgb)
    return pixels



def _encode_float_color(rgb):
    # Sample Blender's working-space conversion on the three basis colours
    # and apply the resulting linear transform to the entire image at once.
    basis = [Color(axis) for axis in ((1, 0, 0), (0, 1, 0), (0, 0, 1))]
    if hasattr(Color, "from_scene_linear_to_rec709_linear"):
        matrix = np.asarray([tuple(axis.from_scene_linear_to_rec709_linear()) for axis in basis],
                            dtype=np.float32)
    else:
        # Older Blender exposes the reverse transform through encoded sRGB.
        # Each basis component is 0 or 1, unchanged by sRGB decoding.
        inverse = [tuple(axis.from_srgb_to_scene_linear()) for axis in basis]
        matrix = np.linalg.inv(np.asarray(inverse, dtype=np.float32))
    if not np.allclose(matrix, np.eye(3), atol=1e-6, rtol=0):
        rgb[:] = rgb @ matrix

    positive = rgb > 0.0031308
    rgb[~positive] *= 12.92
    rgb[positive] = 1.055 * rgb[positive] ** (1 / 2.4) - 0.055


_EXPORT_DEFAULTS = {
    "ROUGHNESS": (1, 1, 1, 1),
    "NORMAL": (128 / 255, 128 / 255, 1, 1),
}


def opacity_source(material):
    opacity = find_texture_node(material, "OPACITY")
    if opacity is not None and opacity.image is not None:
        return "Opacity red"
    base = find_texture_node(material, "BASE_COLOR")
    if base is not None and base.image is not None:
        if base.image.alpha_mode != "NONE" and base.image.channels in (2, 4):
            return "Base Color alpha"
    return "Opaque"


def _process_normal(normal, directx, normalize):
    rgb = normal[:, :3]
    if directx:
        rgb[:, 1] = 1 - rgb[:, 1]
    if normalize:
        # Match Combiner's RGBA8 input, signed-vector math and rounding.
        if not np.isfinite(rgb).all():
            raise CS2ExportError("Normal contains non-finite pixels")
        vectors = np.floor(np.clip(rgb.astype(np.float64), 0, 1) * 255 + 0.5)
        vectors = vectors / 255 * 2 - 1
        lengths = np.linalg.norm(vectors, axis=1)
        valid = lengths > 0.000001
        vectors[valid] /= lengths[valid, None]
        encoded = np.floor((np.clip(vectors, -1, 1) * 0.5 + 0.5) * 255 + 0.5)
        encoded[~valid] = (127, 127, 255)
        rgb[:] = encoded / 255
    normal[:, 3] = 1


def _validate_source_dimensions(material, width, height):
    mismatches = []
    for slot, settings in TEXTURE_SLOTS.items():
        texture_node = find_texture_node(material, slot)
        image = texture_node.image if texture_node is not None else None
        if image is not None and tuple(image.size) != (width, height):
            mismatches.append(
                f"{settings['label']} ({image.size[0]}×{image.size[1]})"
            )
    if mismatches:
        raise CS2ExportError(
            f"All source textures must match BaseColor ({width}×{height}): "
            + ", ".join(mismatches)
            + ". Textures are never resized"
        )


_PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


def _png_chunk(stream, kind, data):
    stream.write(struct.pack(">I", len(data)))
    stream.write(kind)
    stream.write(data)
    stream.write(struct.pack(">I", zlib.crc32(data, zlib.crc32(kind))))


def _write_png(path, width, height, pixels):
    if not np.isfinite(pixels).all():
        raise CS2ExportError(f"{path.name} contains non-finite pixels")

    # Encode straight RGBA8 directly. Blender's saving APIs may interpret
    # RGB using the active OCIO config or the scene's display settings.
    expected = np.empty((height, width, 4), dtype=np.uint8)
    for row, source in zip(expected, pixels.reshape(height, width, 4)):
        row[:] = np.floor(np.clip(source.astype(np.float64), 0, 1) * 255 + 0.5)

    with path.open("wb") as stream:
        stream.write(_PNG_SIGNATURE)
        _png_chunk(stream, b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
        compressor = zlib.compressobj(level=3)
        # PNG rows start at the top. Blender's pixel buffers start at the bottom.
        for row in expected[::-1]:
            data = compressor.compress(b"\x00" + row.tobytes())
            if data:
                _png_chunk(stream, b"IDAT", data)
        _png_chunk(stream, b"IDAT", compressor.flush())
        _png_chunk(stream, b"IEND", b"")

    _validate_png_container(path, width, height)
    decoded = bpy.data.images.load(str(path), check_existing=False)
    try:
        decoded.alpha_mode = "CHANNEL_PACKED"
        decoded.reload()
        if (tuple(decoded.size) != (width, height) or decoded.is_float
                or decoded.depth != 32 or len(decoded.pixels) != expected.size):
            raise CS2ExportError(f"Could not decode all RGBA8 pixels in {path.name}")
        actual = np.empty(expected.shape, dtype=np.float32)
        decoded.pixels.foreach_get(actual.ravel())
        for row, reference in zip(actual, expected):
            if not np.array_equal(np.rint(row * 255), reference):
                raise CS2ExportError(f"Saved pixel values do not match {path.name}")
    finally:
        bpy.data.images.remove(decoded)


def _validate_png_container(path, width, height):
    def invalid():
        return CS2ExportError(f"{path.name} is not an intact {width}×{height} RGBA8 PNG")

    with path.open("rb") as stream:
        if stream.read(8) != _PNG_SIGNATURE:
            raise invalid()
        first = True
        has_data = False
        while True:
            header = stream.read(8)
            if len(header) != 8:
                raise invalid()
            size, kind = struct.unpack(">I4s", header)
            if first:
                if (kind != b"IHDR" or size != 13
                        or stream.read(13) != struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)):
                    raise invalid()
                stream.seek(-13, 1)
                first = False
            checksum = zlib.crc32(kind)
            remaining = size
            while remaining:
                data = stream.read(min(remaining, 65536))
                if not data:
                    raise invalid()
                checksum = zlib.crc32(data, checksum)
                remaining -= len(data)
            if stream.read(4) != struct.pack(">I", checksum):
                raise invalid()
            if kind == b"IDAT":
                has_data |= size > 0
            if kind == b"IEND":
                if not has_data or size or stream.read(1):
                    raise invalid()
                return


def _protect_sources(material, paths):
    sources = []
    for slot in TEXTURE_SLOTS:
        node = find_texture_node(material, slot)
        image = node.image if node else None
        if image and image.filepath:
            sources.append(Path(bpy.path.abspath(image.filepath, library=image.library)))
    for path in paths:
        if path.is_symlink() or (path.exists() and not path.is_file()):
            raise CS2ExportError(f"Output is not a regular file: {path}")
        for source in sources:
            if path.resolve() == source.resolve() or (
                path.exists() and source.exists() and path.samefile(source)
            ):
                raise CS2ExportError(f"Output would replace a source texture: {path.name}")


def _publish(staged, paths, backup):
    # Take all backups before touching any output. Keep backups separate from
    # staging so even a failed rollback cannot discard the originals.
    backup.mkdir()
    originals = {}
    for path in paths.values():
        if path.exists():
            originals[path] = Path(shutil.copy2(path, backup / path.name))

    manifest = backup / "absent.json"
    pending = backup / "absent.tmp"
    pending.write_text(
        json.dumps([path.name for path in paths.values() if path not in originals]),
        encoding="utf-8",
    )
    pending.replace(manifest)
    attempted = []
    try:
        for suffix, path in paths.items():
            attempted.append((staged[suffix], path))
            staged[suffix].replace(path)
    except BaseException as error:
        failures = []
        for staged_file, path in reversed(attempted):
            # An interrupt can land after rename but before replace returns.
            # A failed rename leaves the staged file in place.
            try:
                if staged_file.exists():
                    continue
                if path in originals:
                    restore = backup.parent / ("restore-" + path.name)
                    shutil.copy2(originals[path], restore)
                    restore.replace(path)
                else:
                    path.unlink(missing_ok=True)
            except BaseException as restore_error:
                failures.append(f"{path.name}: {restore_error}")
        if failures:
            raise RecoveryRequired(
                f"Replacement failed ({error}); rollback incomplete. "
                f"Recovery files: {backup}. " + "; ".join(failures)
            ) from error
        manifest.unlink()
        raise
    manifest.unlink()


class RecoveryRequired(CS2ExportError):
    pass


def _stage_textures(material, staged, width, height, directx, normalize):
    base = _slot_pixels(material, "BASE_COLOR", width, height)
    source = opacity_source(material)
    if source == "Opacity red":
        opacity = _slot_pixels(material, "OPACITY", width, height)
        base[:, 3] = opacity[:, 0]
    elif source == "Opaque":
        base[:, 3] = 1.0
    _write_png(staged["BaseColor"], width, height, base)
    del base

    control = np.zeros((width * height, 4), dtype=np.float32)
    for channel, slot in enumerate(("COLOR_MASK_1", "COLOR_MASK_2", "COLOR_MASK_3")):
        source = _slot_pixels(material, slot, width, height)
        control[:, channel] = source[:, 0]
        del source
    snow = _slot_pixels(material, "SNOW_REMOVE", width, height)
    control[:, 3] = snow[:, 0]
    del snow
    _write_png(staged["ControlMask"], width, height, control)
    del control

    mask = np.zeros((width * height, 4), dtype=np.float32)
    metallic = _slot_pixels(material, "METALLIC", width, height)
    mask[:, 0] = metallic[:, 0]
    del metallic
    coat = _slot_pixels(material, "COAT", width, height)
    mask[:, 1] = coat[:, 0]
    del coat
    roughness = _slot_pixels(material, "ROUGHNESS", width, height)
    mask[:, 3] = 1.0 - roughness[:, 0]
    del roughness
    _write_png(staged["MaskMap"], width, height, mask)
    del mask

    normal = _slot_pixels(material, "NORMAL", width, height)
    normal_node = find_texture_node(material, "NORMAL")
    if normal_node is not None and normal_node.image is not None:
        _process_normal(
            normal,
            directx, normalize,
        )
    _write_png(staged["Normal"], width, height, normal)
    del normal

    emissive = _slot_pixels(material, "EMISSION", width, height)
    emissive[:, 3] = 1.0
    _write_png(staged["Emissive"], width, height, emissive)
    del emissive


def export_cs2_texture_set(material, directory, asset_name, scene=None, *,
                           directx=None, normalize=None):
    if directx is None:
        directx = getattr(material, "mw_cs2_normal_source", "OPENGL") == "DIRECTX"
    if normalize is None:
        normalize = getattr(material, "mw_cs2_normalize_export", True)
    if not is_mw_material(material):
        raise CS2ExportError("The active material is not an MW CS2 material")

    group_node = find_material_group_node(material)
    if group_node is None or group_node.node_tree is None:
        raise CS2ExportError("The MW material group is missing")

    base_node = find_texture_node(material, "BASE_COLOR")
    if base_node is None or base_node.image is None:
        raise CS2ExportError("Load a Base Color texture before exporting")

    width, height = base_node.image.size
    if width <= 0 or height <= 0:
        raise CS2ExportError("The Base Color image has no pixel data")
    if width != height:
        raise CS2ExportError("CS2 textures must be square (1:1)")
    _validate_source_dimensions(material, width, height)

    prefix = _safe_asset_name(asset_name)
    if not prefix:
        raise CS2ExportError("Enter a valid CS2 asset name")

    output_directory = Path(bpy.path.abspath(str(directory))).expanduser()
    output_directory.mkdir(parents=True, exist_ok=True)
    paths = {
        suffix: output_directory / f"{prefix}_{suffix}.png"
        for suffix in ("BaseColor", "ControlMask", "MaskMap", "Normal", "Emissive")
    }

    # A directory lock serializes add-on exports into this destination.
    lock = output_directory / ".mw-cs2-export"
    try:
        lock.mkdir()
    except FileExistsError as error:
        raise CS2ExportError(f"Export already active or recovery required: {lock}") from error
    journal = lock / "originals" / "absent.json"
    phase = "prepare destination"
    warnings = []
    try:
        _protect_sources(material, paths.values())
        staging = lock / "staged-textures"
        staging.mkdir()
        staged = {suffix: staging / path.name for suffix, path in paths.items()}
        phase = "generate or validate staged PNGs"
        _stage_textures(material, staged, width, height, directx, normalize)
        phase = "publish texture set"
        _protect_sources(material, paths.values())
        _publish(staged, paths, lock / "originals")
    except CS2ExportError:
        raise
    except Exception as error:
        message = f"Could not {phase}: {error}"
        if journal.exists():
            raise RecoveryRequired(f"{message}. Recovery files: {journal.parent}") from error
        raise CS2ExportError(message) from error
    finally:
        # An active journal means publish or rollback did not reach its
        # completion point. Keep the recovery data even on an interruption.
        if not journal.exists():
            export_error = sys.exception()
            try:
                shutil.rmtree(lock)
            except OSError as error:
                cleanup_warning = f"Could not remove temporary export files at {lock}: {error}"
                if isinstance(export_error, Exception):
                    raise CS2ExportError(f"{export_error}. {cleanup_warning}") from export_error
                warnings.append(cleanup_warning)

    if width < 512:
        warnings.append(f"{width}×{height} is below the recommended 512×512 minimum")
    elif width not in (512, 1024, 2048, 4096):
        warnings.append("Combiner Building expects 512, 1024, 2048, or 4096 pixels")
    return tuple(paths.values()), tuple(warnings)
