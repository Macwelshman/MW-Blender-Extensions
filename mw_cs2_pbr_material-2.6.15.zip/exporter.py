from __future__ import annotations

from pathlib import Path
import json
import shutil
import struct
import zlib
from tempfile import TemporaryDirectory

import bpy
import numpy as np

from .constants import TEXTURE_SLOTS
from .nodes import (
    find_material_group_node,
    find_texture_node,
    is_mw_material,
)


class CS2ExportError(RuntimeError):
    pass


def _safe_asset_name(name: str) -> str:
    cleaned = name.strip()
    if cleaned.lower().endswith(".fbx"):
        cleaned = cleaned[:-4]
    for character in '<>:"/\\|?*':
        cleaned = cleaned.replace(character, "_")
    return cleaned.strip(". ")


def _slot_pixels(material, slot, width, height):
    texture_node = find_texture_node(material, slot)
    image = texture_node.image if texture_node is not None else None
    if image is None:
        default = np.asarray(_EXPORT_DEFAULTS.get(slot, TEXTURE_SLOTS[slot]["default"]), dtype=np.float32)
        return np.broadcast_to(default, (width * height, 4)).copy()

    if tuple(image.size) != (width, height):
        raise CS2ExportError(
            f"{TEXTURE_SLOTS[slot]['label']} must be {width}×{height} to match BaseColor. "
            "Textures are never resized"
        )

    pixels = np.empty(width * height * 4, dtype=np.float32)
    image.pixels.foreach_get(pixels)
    pixels = pixels.reshape((-1, 4))
    # Blender exposes byte images as encoded samples, float colour images as
    # scene-linear samples. Alpha and data maps are never gamma corrected.
    if image.is_float and slot in {"BASE_COLOR", "EMISSION"}:
        rgb = pixels[:, :3]
        positive = rgb > 0.0031308
        rgb[~positive] *= 12.92
        rgb[positive] = 1.055 * rgb[positive] ** (1 / 2.4) - 0.055
    return pixels


_EXPORT_DEFAULTS = {
    "ROUGHNESS": (1, 1, 1, 1),
    "NORMAL": (128 / 255, 128 / 255, 1, 1),
}


def opacity_source(material):
    opacity = find_texture_node(material, "OPACITY")
    if opacity is not None and opacity.image is not None:
        return "Opacity red"
    base = find_texture_node(material, "BASE_COLOR")
    if base is not None and base.image is not None:
        if base.image.alpha_mode != "NONE" and base.image.channels in (2, 4):
            return "Base Color alpha"
    return "Opaque"


def _process_normal(normal, directx, normalize):
    rgb = normal[:, :3]
    if directx:
        rgb[:, 1] = 1 - rgb[:, 1]
    if normalize:
        # Match Combiner's RGBA8 input, signed-vector math and rounding.
        if not np.isfinite(rgb).all():
            raise CS2ExportError("Normal contains non-finite pixels")
        vectors = np.floor(np.clip(rgb.astype(np.float64), 0, 1) * 255 + 0.5)
        vectors = vectors / 255 * 2 - 1
        lengths = np.linalg.norm(vectors, axis=1)
        valid = lengths > 0.000001
        vectors[valid] /= lengths[valid, None]
        encoded = np.floor((np.clip(vectors, -1, 1) * 0.5 + 0.5) * 255 + 0.5)
        encoded[~valid] = (127, 127, 255)
        rgb[:] = encoded / 255
    normal[:, 3] = 1


def _validate_source_dimensions(material, width, height):
    mismatches = []
    for slot, settings in TEXTURE_SLOTS.items():
        texture_node = find_texture_node(material, slot)
        image = texture_node.image if texture_node is not None else None
        if image is not None and tuple(image.size) != (width, height):
            mismatches.append(
                f"{settings['label']} ({image.size[0]}×{image.size[1]})"
            )
    if mismatches:
        raise CS2ExportError(
            f"All source textures must match BaseColor ({width}×{height}): "
            + ", ".join(mismatches)
            + ". Textures are never resized"
        )


def _write_png(path, width, height, pixels, color_space):
    if not np.isfinite(pixels).all():
        raise CS2ExportError(f"{path.name} contains non-finite pixels")
    image = bpy.data.images.new(
        name=f"MW CS2 Export - {path.name}",
        width=width,
        height=height,
        alpha=True,
        float_buffer=False,
    )
    try:
        image.colorspace_settings.name = color_space
        image.alpha_mode = "CHANNEL_PACKED"
        image.file_format = "PNG"
        image.filepath_raw = str(path)
        image.pixels.foreach_set(np.ascontiguousarray(pixels, dtype=np.float32).ravel())
        image.update()
        image.save()
    finally:
        bpy.data.images.remove(image)

    # Check the actual file format, then decode and compare every stored channel.
    _validate_png_container(path, width, height)
    decoded = bpy.data.images.load(str(path), check_existing=False)
    try:
        decoded.colorspace_settings.name = color_space
        decoded.alpha_mode = "CHANNEL_PACKED"
        decoded.reload()
        if tuple(decoded.size) != (width, height) or len(decoded.pixels) != pixels.size:
            raise CS2ExportError(f"Could not decode all pixels in {path.name}")
        actual = np.empty_like(pixels)
        decoded.pixels.foreach_get(actual.ravel())
        if not np.allclose(actual, np.clip(pixels, 0, 1), atol=0.501 / 255, rtol=0):
            raise CS2ExportError(f"Saved pixel values do not match {path.name}")
    finally:
        bpy.data.images.remove(decoded)


def _validate_png_container(path, width, height):
    def invalid():
        return CS2ExportError(f"{path.name} is not an intact {width}×{height} RGBA8 PNG")

    with path.open("rb") as stream:
        if stream.read(8) != b"\x89PNG\r\n\x1a\n":
            raise invalid()
        first = True
        while True:
            header = stream.read(8)
            if len(header) != 8:
                raise invalid()
            size, kind = struct.unpack(">I4s", header)
            if first:
                if (kind != b"IHDR" or size != 13
                        or stream.read(10) != struct.pack(">IIBB", width, height, 8, 6)):
                    raise invalid()
                stream.seek(-10, 1)
                first = False
            checksum = zlib.crc32(kind)
            remaining = size
            while remaining:
                data = stream.read(min(remaining, 65536))
                if not data:
                    raise invalid()
                checksum = zlib.crc32(data, checksum)
                remaining -= len(data)
            if stream.read(4) != struct.pack(">I", checksum):
                raise invalid()
            if kind == b"IEND":
                if size or stream.read(1):
                    raise invalid()
                return


def _protect_sources(material, paths):
    sources = []
    for slot in TEXTURE_SLOTS:
        node = find_texture_node(material, slot)
        image = node.image if node else None
        if image and image.filepath:
            sources.append(Path(bpy.path.abspath(image.filepath, library=image.library)))
    for path in paths:
        if path.is_symlink() or (path.exists() and not path.is_file()):
            raise CS2ExportError(f"Output is not a regular file: {path}")
        for source in sources:
            if path.resolve() == source.resolve() or (
                path.exists() and source.exists() and path.samefile(source)
            ):
                raise CS2ExportError(f"Output would replace a source texture: {path.name}")


def _publish(staged, paths, backup):
    # Take all backups before touching any output. Keep backups separate from
    # staging so even a failed rollback cannot discard the originals.
    backup.mkdir()
    originals = {}
    for path in paths.values():
        if path.exists():
            originals[path] = Path(shutil.copy2(path, backup / path.name))

    (backup / "absent.json").write_text(
        json.dumps([path.name for path in paths.values() if path not in originals]),
        encoding="utf-8",
    )
    replaced = []
    try:
        for suffix, path in paths.items():
            staged[suffix].replace(path)
            replaced.append(path)
    except BaseException as error:
        failures = []
        for path in reversed(replaced):
            try:
                if path in originals:
                    restore = backup.parent / ("restore-" + path.name)
                    shutil.copy2(originals[path], restore)
                    restore.replace(path)
                else:
                    path.unlink()
            except OSError as restore_error:
                failures.append(f"{path.name}: {restore_error}")
        if failures:
            raise RecoveryRequired(
                f"Replacement failed ({error}); rollback incomplete. "
                f"Recovery files: {backup}. " + "; ".join(failures)
            ) from error
        raise


class RecoveryRequired(CS2ExportError):
    pass


def _stage_textures(material, staged, width, height, directx, normalize):
    base = _slot_pixels(material, "BASE_COLOR", width, height)
    source = opacity_source(material)
    if source == "Opacity red":
        opacity = _slot_pixels(material, "OPACITY", width, height)
        base[:, 3] = opacity[:, 0]
    elif source == "Opaque":
        base[:, 3] = 1.0
    _write_png(staged["BaseColor"], width, height, base, "sRGB")
    del base

    control = np.zeros((width * height, 4), dtype=np.float32)
    for channel, slot in enumerate(("COLOR_MASK_1", "COLOR_MASK_2", "COLOR_MASK_3")):
        source = _slot_pixels(material, slot, width, height)
        control[:, channel] = source[:, 0]
        del source
    snow = _slot_pixels(material, "SNOW_REMOVE", width, height)
    control[:, 3] = snow[:, 0]
    del snow
    _write_png(staged["ControlMask"], width, height, control, "Non-Color")
    del control

    mask = np.zeros((width * height, 4), dtype=np.float32)
    metallic = _slot_pixels(material, "METALLIC", width, height)
    mask[:, 0] = metallic[:, 0]
    del metallic
    coat = _slot_pixels(material, "COAT", width, height)
    mask[:, 1] = coat[:, 0]
    del coat
    roughness = _slot_pixels(material, "ROUGHNESS", width, height)
    mask[:, 3] = 1.0 - roughness[:, 0]
    del roughness
    _write_png(staged["MaskMap"], width, height, mask, "Non-Color")
    del mask

    normal = _slot_pixels(material, "NORMAL", width, height)
    normal_node = find_texture_node(material, "NORMAL")
    if normal_node is not None and normal_node.image is not None:
        _process_normal(
            normal,
            directx, normalize,
        )
    _write_png(staged["Normal"], width, height, normal, "Non-Color")
    del normal

    emissive = _slot_pixels(material, "EMISSION", width, height)
    emissive[:, 3] = 1.0
    _write_png(staged["Emissive"], width, height, emissive, "sRGB")
    del emissive


def export_cs2_texture_set(material, directory, asset_name, scene=None, *,
                           directx=None, normalize=None):
    if directx is None:
        directx = getattr(material, "mw_cs2_normal_source", "OPENGL") == "DIRECTX"
    if normalize is None:
        normalize = getattr(material, "mw_cs2_normalize_export", True)
    if not is_mw_material(material):
        raise CS2ExportError("The active material is not an MW CS2 material")

    group_node = find_material_group_node(material)
    if group_node is None or group_node.node_tree is None:
        raise CS2ExportError("The MW material group is missing")

    base_node = find_texture_node(material, "BASE_COLOR")
    if base_node is None or base_node.image is None:
        raise CS2ExportError("Load a Base Color texture before exporting")

    width, height = base_node.image.size
    if width <= 0 or height <= 0:
        raise CS2ExportError("The Base Color image has no pixel data")
    if width != height:
        raise CS2ExportError("CS2 textures must be square (1:1)")
    _validate_source_dimensions(material, width, height)

    prefix = _safe_asset_name(asset_name)
    if not prefix:
        raise CS2ExportError("Enter a valid CS2 asset name")

    output_directory = Path(bpy.path.abspath(str(directory))).expanduser()
    output_directory.mkdir(parents=True, exist_ok=True)
    paths = {
        suffix: output_directory / f"{prefix}_{suffix}.png"
        for suffix in ("BaseColor", "ControlMask", "MaskMap", "Normal", "Emissive")
    }

    # A directory lock serializes add-on exports into this destination.
    lock = output_directory / ".mw-cs2-export"
    try:
        lock.mkdir()
    except FileExistsError as error:
        raise CS2ExportError(f"Export already active or recovery required: {lock}") from error
    preserve_recovery = False
    try:
        _protect_sources(material, paths.values())
        with TemporaryDirectory(prefix="staged-", dir=lock) as staging:
            staged = {suffix: Path(staging) / path.name for suffix, path in paths.items()}
            _stage_textures(material, staged, width, height, directx, normalize)
            _protect_sources(material, paths.values())
            _publish(staged, paths, lock / "originals")
    except RecoveryRequired:
        preserve_recovery = True
        raise
    finally:
        if not preserve_recovery:
            shutil.rmtree(lock, ignore_errors=True)

    warnings = []
    if width < 512:
        warnings.append(f"{width}×{height} is below the recommended 512×512 minimum")
    elif width not in (512, 1024, 2048, 4096):
        warnings.append("Combiner Building expects 512, 1024, 2048, or 4096 pixels")
    return tuple(paths.values()), tuple(warnings)
