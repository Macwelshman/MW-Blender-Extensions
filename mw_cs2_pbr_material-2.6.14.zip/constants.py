ADDON_VERSION = (2, 6, 14)
MATERIAL_MARKER = "mw_cs2_pbr_material"
MATERIAL_SCHEMA_KEY = "mw_cs2_schema"
MATERIAL_SCHEMA_VERSION = 8
MATERIAL_RELOAD_BACKUP_KEY = "mw_cs2_reload_backup"
GROUP_NODE_MARKER = "mw_cs2_group_node"
IMAGE_MARKER = "mw_cs2_source_image"
PREVIEW_SLOT_KEY = "mw_cs2_preview_slot"
PREVIEW_VIEW_TRANSFORM_KEY = "mw_cs2_preview_previous_view_transform"

GROUP_NODE_NAME = "MW CS2 PBR Material"
PRINCIPLED_NODE_NAME = "MW Principled BSDF"
PREVIEW_NODE_NAME = "MW Texture Preview"

TEXTURE_SLOTS = {
    "BASE_COLOR": {
        "label": "Base Color",
        "map_name": "BaseColor",
        "node": "MW Texture - Base Color",
        "color_space": "sRGB",
        "default": (0.8, 0.8, 0.8, 1.0),
    },
    "ROUGHNESS": {
        "label": "Roughness",
        "map_name": "Roughness",
        "node": "MW Texture - Roughness",
        "color_space": "Non-Color",
        "default": (0.5, 0.5, 0.5, 1.0),
    },
    "NORMAL": {
        "label": "Normal (OpenGL)",
        "map_name": "Normal",
        "node": "MW Texture - Normal",
        "color_space": "Non-Color",
        "default": (0.5, 0.5, 1.0, 1.0),
    },
    "METALLIC": {
        "label": "Metallic",
        "map_name": "Metallic",
        "node": "MW Texture - Metallic",
        "color_space": "Non-Color",
        "default": (0.0, 0.0, 0.0, 1.0),
    },
    "OPACITY": {
        "label": "Opacity",
        "map_name": "Opacity",
        "node": "MW Texture - Opacity",
        "color_space": "Non-Color",
        "default": (1.0, 1.0, 1.0, 1.0),
    },
    "EMISSION": {
        "label": "Emission",
        "map_name": "Emission",
        "node": "MW Texture - Emission",
        "color_space": "sRGB",
        "default": (0.0, 0.0, 0.0, 1.0),
    },
    "COLOR_MASK_1": {
        "label": "Colour Mask 1",
        "map_name": "Color Mask 1",
        "node": "MW Texture - Colour Mask 1",
        "color_space": "Non-Color",
        "default": (0.0, 0.0, 0.0, 1.0),
    },
    "COLOR_MASK_2": {
        "label": "Colour Mask 2",
        "map_name": "Color Mask 2",
        "node": "MW Texture - Colour Mask 2",
        "color_space": "Non-Color",
        "default": (0.0, 0.0, 0.0, 1.0),
    },
    "COLOR_MASK_3": {
        "label": "Colour Mask 3",
        "map_name": "Color Mask 3",
        "node": "MW Texture - Colour Mask 3",
        "color_space": "Non-Color",
        "default": (0.0, 0.0, 0.0, 1.0),
    },
    "COAT": {
        "label": "Coat",
        "map_name": "Coat",
        "node": "MW Texture - Coat",
        "color_space": "Non-Color",
        "default": (0.0, 0.0, 0.0, 1.0),
    },
    "SNOW_REMOVE": {
        "label": "Snow Remove",
        "map_name": "Snow Remove",
        "node": "MW Texture - Snow Remove",
        "color_space": "Non-Color",
        "default": (0.0, 0.0, 0.0, 1.0),
    },
}

TEXTURE_SLOT_ITEMS = tuple(
    (slot, settings["label"], f"Set {settings['map_name']} texture map")
    for slot, settings in TEXTURE_SLOTS.items()
)

PREVIEW_SLOT_ITEMS = (
    ("MATERIAL", "Material", "Preview the complete material"),
) + tuple(
    (slot, settings["label"], f"Preview {settings['map_name']} texture map")
    for slot, settings in TEXTURE_SLOTS.items()
)
