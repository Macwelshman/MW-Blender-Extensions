from pathlib import Path
from types import SimpleNamespace

import bpy

from .constants import PREVIEW_SLOT_KEY, TEXTURE_SLOTS
from .nodes import (
    find_material_group_node,
    find_texture_node,
    is_mw_material,
    migrate_authoring_material,
)


UI_TITLE = "MW CS2 PBR Material"


PREVIEW_COLUMNS = (
    (
        ("MATERIAL", "Material"),
        ("BASE_COLOR", "BaseColor"),
        ("ROUGHNESS", "Roughness"),
        ("NORMAL", "Normal"),
        ("METALLIC", "Metallic"),
        ("OPACITY", "Opacity"),
    ),
    (
        ("EMISSION", "Emission"),
        ("COLOR_MASK_1", "Mask 1"),
        ("COLOR_MASK_2", "Mask 2"),
        ("COLOR_MASK_3", "Mask 3"),
        ("COAT", "Coat"),
        ("SNOW_REMOVE", "Snow"),
    ),
)


def _active_material(context):
    return getattr(context, "material", None) or getattr(
        getattr(context, "object", None), "active_material", None
    )


def _draw_group_value(layout, group_node, name, label):
    socket = group_node.inputs.get(name)
    if socket is not None:
        layout.prop(socket, "default_value", text=label)


def _loaded_texture_count(material):
    return sum(
        bool((node := find_texture_node(material, slot)) and node.image)
        for slot in TEXTURE_SLOTS
    )


def _display_image_name(image):
    filepath = getattr(image, "filepath", "")
    if filepath:
        filename = Path(bpy.path.abspath(filepath)).name
        if filename:
            return filename
    return image.name


def _draw_embedded(panel_type, layout, context):
    panel = SimpleNamespace(layout=layout)
    panel_type.draw(panel, context)


def _draw_material_interface(layout, context):
    material = _active_material(context)
    if not is_mw_material(material):
        box = layout.box()
        heading = box.row()
        heading.scale_y = 1.3
        heading.label(text=UI_TITLE, icon="MATERIAL")
        box.label(text="No MW material is active", icon="INFO")
        box.label(text="Use the Create button above to begin.")
        return

    migrate_authoring_material(material)
    identity = layout.box()
    heading = identity.row(align=True)
    heading.scale_y = 1.35
    heading.label(text=UI_TITLE, icon="NODE_MATERIAL")

    _draw_embedded(MW_PT_settings, layout, context)

    sections = (
        ("mw_cs2_masks", "Colour Mask Preview", "COLOR", MW_PT_masks, False),
        ("mw_cs2_textures", "Source Textures", "TEXTURE", MW_PT_textures, False),
        ("mw_cs2_preview", "Bake Previews", "RENDER_STILL", MW_PT_preview, False),
        ("mw_cs2_export", "CS2 Texture Export", "EXPORT", MW_PT_export, True),
    )
    for panel_id, label, icon, panel_type, default_closed in sections:
        header, body = layout.panel(panel_id, default_closed=default_closed)
        if panel_id == "mw_cs2_preview":
            header.alignment = "LEFT"
            hint = header.operator(
                "mw_cs2.ui_hint",
                text=label,
                icon=icon,
                emboss=False,
            )
            hint.topic = "BAKE_PREVIEW"
        else:
            header.label(text=label, icon=icon)
            if panel_id == "mw_cs2_textures":
                header.operator(
                    "mw_cs2.reload_all_textures",
                    text="Reload All",
                    icon="FILE_REFRESH",
                )
        if body is not None:
            _draw_embedded(panel_type, body, context)


class MW_PT_material(bpy.types.Panel):
    bl_label = UI_TITLE
    bl_idname = "MW_PT_cs2_pbr_material"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "material"
    bl_order = 1

    @classmethod
    def poll(cls, context):
        obj = getattr(context, "object", None)
        return bool(obj and getattr(getattr(obj, "data", None), "materials", None) is not None)

    def draw(self, context):
        _draw_material_interface(self.layout, context)


class MW_PT_textures(bpy.types.Panel):
    bl_label = "Source Textures"
    bl_idname = "MW_PT_cs2_pbr_textures"
    bl_parent_id = MW_PT_material.bl_idname
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "material"
    bl_order = 2

    @classmethod
    def poll(cls, context):
        return is_mw_material(_active_material(context))

    def draw(self, context):
        layout = self.layout
        material = _active_material(context)

        loaded = _loaded_texture_count(material)
        total = len(TEXTURE_SLOTS)
        summary = layout.box()
        summary.progress(
            factor=loaded / total,
            text=f"{loaded} of {total} textures loaded",
        )

        actions = summary.row()
        actions.operator(
            "mw_cs2.remove_all_textures",
            text="Remove All",
            icon="TRASH",
        )
        for slot, settings in TEXTURE_SLOTS.items():
            texture_node = find_texture_node(material, slot)
            has_image = bool(texture_node and texture_node.image)
            box = layout.box()
            heading = box.row(align=True)
            heading.alignment = "LEFT"
            if slot == "BASE_COLOR":
                hint = heading.operator(
                    "mw_cs2.ui_hint",
                    text="BaseColor",
                    emboss=False,
                )
                hint.topic = "BASE_COLOR"
            elif slot == "NORMAL":
                heading.label(text="Normal")
            else:
                heading.label(text=settings["label"])

            row = box.row(align=True)
            if has_image:
                row.label(text=_display_image_name(texture_node.image))
            else:
                row.label(text="Not loaded")

            load = row.operator(
                "mw_cs2.load_texture",
                text="" if has_image else "Load",
                icon="FILE_FOLDER",
            )
            load.slot = slot

            existing = row.operator_menu_enum(
                "mw_cs2.use_existing_image",
                "image_name",
                text="",
                icon="IMAGE_DATA",
            )
            existing.slot = slot

            if has_image:
                clear_op = row.operator("mw_cs2.clear_texture", text="", icon="X")
                clear_op.slot = slot


class MW_PT_settings(bpy.types.Panel):
    bl_label = "Authoring Preview Settings"
    bl_idname = "MW_PT_cs2_pbr_settings"
    bl_parent_id = MW_PT_material.bl_idname
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "material"
    bl_options = {"HIDE_HEADER"}
    bl_order = 0

    @classmethod
    def poll(cls, context):
        return is_mw_material(_active_material(context))

    def draw(self, context):
        layout = self.layout
        group_node = find_material_group_node(_active_material(context))
        if group_node is None:
            layout.label(text="Material group is missing", icon="ERROR")
            return

        card = layout.box()
        toggles = card.row(align=True)
        toggles.scale_y = 1.35
        toggles.prop(
            _active_material(context),
            "use_backface_culling",
            text="Hide Backfaces",
            icon="NORMALS_FACE",
            toggle=True,
        )
        controls = card.column(align=True)
        controls.use_property_split = True
        controls.use_property_decorate = False
        _draw_group_value(controls, group_node, "Emission Strength", "Emission Strength")


class MW_PT_preview(bpy.types.Panel):
    bl_label = "Bake Previews"
    bl_idname = "MW_PT_cs2_pbr_preview"
    bl_parent_id = MW_PT_material.bl_idname
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "material"
    bl_order = 3

    @classmethod
    def poll(cls, context):
        return is_mw_material(_active_material(context))

    def draw(self, context):
        layout = self.layout
        group_node = find_material_group_node(_active_material(context))
        if group_node is None or group_node.node_tree is None:
            layout.label(text="Material group is missing", icon="ERROR")
            return

        current = group_node.node_tree.get(PREVIEW_SLOT_KEY, "MATERIAL")
        columns = layout.split(factor=0.5, align=True)
        for column_items in PREVIEW_COLUMNS:
            column = columns.column(align=True)
            for slot, label in column_items:
                is_complete = slot == "MATERIAL"
                preview_op = column.operator(
                    "mw_cs2.preview_texture",
                    text=label,
                    icon=(
                        "MATERIAL"
                        if is_complete
                        else "IMAGE_DATA"
                    ),
                    depress=current == slot,
                )
                preview_op.slot = slot


class MW_PT_masks(bpy.types.Panel):
    bl_label = "Colour Mask Preview"
    bl_idname = "MW_PT_cs2_pbr_masks"
    bl_parent_id = MW_PT_material.bl_idname
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "material"
    bl_order = 1

    @classmethod
    def poll(cls, context):
        return is_mw_material(_active_material(context))

    def draw(self, context):
        layout = self.layout
        group_node = find_material_group_node(_active_material(context))
        if group_node is None:
            layout.label(text="Material group is missing", icon="ERROR")
            return

        for index in range(1, 4):
            box = layout.box()
            split = box.split(factor=0.3, align=True)
            split.label(text=f"Mask {index}")
            controls = split.row(align=True)
            controls.prop(
                group_node.inputs[f"CM{index} Colour"],
                "default_value",
                text="",
            )
            reset = controls.operator(
                "mw_cs2.reset_mask_color",
                text="",
                icon="LOOP_BACK",
            )
            reset.mask_index = index


class MW_PT_export(bpy.types.Panel):
    bl_label = "CS2 Texture Export"
    bl_idname = "MW_PT_cs2_pbr_export"
    bl_parent_id = MW_PT_material.bl_idname
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "material"
    bl_order = 4

    @classmethod
    def poll(cls, context):
        return is_mw_material(_active_material(context))

    def draw(self, context):
        layout = self.layout
        material = _active_material(context)
        obj = getattr(context, "object", None)
        suggested_name = obj.name if obj is not None else material.name
        has_any_texture = _loaded_texture_count(material) > 0

        content = layout.column()
        content.enabled = has_any_texture

        destination = content.box()
        destination.use_property_split = True
        destination.use_property_decorate = False
        destination.prop(
            material,
            "mw_cs2_export_name",
            text="Asset Name",
            placeholder=suggested_name,
        )

        destination.prop(material, "mw_cs2_export_directory", text="Export Folder")

        base_node = find_texture_node(material, "BASE_COLOR")
        base_image = base_node.image if base_node else None
        has_base = base_image is not None
        is_square = bool(has_base and base_image.size[0] == base_image.size[1])
        dimensions_match = bool(
            has_base
            and all(
                (texture_node := find_texture_node(material, slot)) is None
                or texture_node.image is None
                or tuple(texture_node.image.size) == tuple(base_image.size)
                for slot in TEXTURE_SLOTS
            )
        )
        has_destination = bool(material.mw_cs2_export_directory)
        ready = has_base and is_square and dimensions_match and has_destination

        export_row = content.row()
        export_row.scale_y = 1.5
        export_row.enabled = ready
        export_row.operator_context = "EXEC_DEFAULT"
        export_op = export_row.operator(
            "mw_cs2.export_textures",
            text="Export 5 CS2 Textures",
            icon="EXPORT",
        )
        export_op.asset_name = material.mw_cs2_export_name or suggested_name
        export_op.directory = material.mw_cs2_export_directory


# The complete interface is drawn directly beneath the Create button by the
# native material-selector panel callback. Registering a separate panel would
# allow Blender to place its Surface panel between the two parts of the UI.
classes = ()
