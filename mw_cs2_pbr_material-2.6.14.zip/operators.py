from __future__ import annotations

from pathlib import Path

import bpy
from bpy.props import EnumProperty, IntProperty, StringProperty

from .constants import (
    IMAGE_MARKER,
    PREVIEW_SLOT_ITEMS,
    PREVIEW_SLOT_KEY,
    TEXTURE_SLOT_ITEMS,
    TEXTURE_SLOTS,
)
from .exporter import CS2ExportError, export_cs2_texture_set
from .nodes import (
    create_authoring_material,
    find_material_group_node,
    find_texture_node,
    is_mw_material,
    set_image_color_space,
    set_texture_preview,
    suggested_material_name,
)


def _active_material(context):
    return getattr(context, "material", None) or getattr(
        getattr(context, "object", None), "active_material", None
    )


def _set_color_space(image: bpy.types.Image, slot: str) -> None:
    target = TEXTURE_SLOTS[slot]["color_space"]
    set_image_color_space(image, target)


def _existing_image_items(_self, _context):
    items = [
        (image.name, image.name, f"Use {image.name}")
        for image in sorted(bpy.data.images, key=lambda item: item.name.casefold())
    ]
    return items or [("__NONE__", "No Images Available", "Import an image first")]


_SUPPORTED_IMAGE_EXTENSIONS = {".png", ".tif", ".tiff", ".exr", ".jpg", ".jpeg"}
_BASE_COLOR_ALIASES = ("basecolor", "basecolour", "albedo", "diffuse")
_COMPANION_ALIASES = {
    "ROUGHNESS": ("roughness", "rough"),
    "NORMAL": ("normal", "normalgl", "normalopengl"),
    "METALLIC": ("metallic", "metalness"),
    "COAT": ("coat", "coatmask"),
    "OPACITY": ("opacity", "alpha"),
    "EMISSION": ("emission", "emissive"),
    "COLOR_MASK_1": ("colormask1", "colourmask1", "cm1"),
    "COLOR_MASK_2": ("colormask2", "colourmask2", "cm2"),
    "COLOR_MASK_3": ("colormask3", "colourmask3", "cm3"),
    "SNOW_REMOVE": ("snowremove", "snowremoval"),
}


def _normalise_texture_name(name: str) -> str:
    return "".join(character for character in name.casefold() if character.isalnum())


def _has_blender_number_suffix(name: str) -> bool:
    _base, separator, suffix = name.rpartition(".")
    return bool(separator and len(suffix) == 3 and suffix.isdigit())


def _preferred_image_for_path(path: Path, owner: str):
    target = str(path.resolve())
    candidates = []
    for image in bpy.data.images:
        if not image.filepath:
            continue
        image_path = str(Path(bpy.path.abspath(image.filepath)).resolve())
        if image_path != target:
            continue
        image_owner = image.get(IMAGE_MARKER)
        if image_owner in (None, "", owner):
            candidates.append(image)
    return min(
        candidates,
        key=lambda image: (_has_blender_number_suffix(image.name), image.name.casefold()),
        default=None,
    )


def _load_file_into_slot(material, slot: str, path: Path):
    texture_node = find_texture_node(material, slot)
    if texture_node is None:
        raise ValueError(f"Texture slot {slot} is unavailable")

    owner = f"{material.name}:{slot}"
    image = _preferred_image_for_path(path, owner)
    created = image is None
    try:
        if created:
            image = bpy.data.images.load(str(path), check_existing=False)
        _set_color_space(image, slot)
        image[IMAGE_MARKER] = owner
        texture_node.image = image
        return image
    except Exception:
        if created and image is not None and image.users == 0:
            bpy.data.images.remove(image)
        raise


def _auto_load_base_color_companions(material, base_color_path: Path):
    if not base_color_path.is_file():
        return []

    normalised_base = _normalise_texture_name(base_color_path.stem)
    prefix = None
    for alias in _BASE_COLOR_ALIASES:
        if normalised_base.endswith(alias):
            prefix = normalised_base[: -len(alias)]
            break
    if prefix is None:
        return []

    folder_images = {}
    for path in sorted(base_color_path.parent.iterdir(), key=lambda item: item.name.casefold()):
        if path.is_file() and path.suffix.casefold() in _SUPPORTED_IMAGE_EXTENSIONS:
            folder_images.setdefault(_normalise_texture_name(path.stem), path)

    loaded = []
    for slot, aliases in _COMPANION_ALIASES.items():
        texture_node = find_texture_node(material, slot)
        if texture_node is None or texture_node.image is not None:
            continue
        match = next(
            (folder_images.get(prefix + alias) for alias in aliases if folder_images.get(prefix + alias)),
            None,
        )
        if match is None:
            continue
        try:
            _load_file_into_slot(material, slot, match)
            loaded.append(TEXTURE_SLOTS[slot]["label"])
        except Exception:
            continue
    return loaded


class MW_OT_create_material(bpy.types.Operator):
    bl_idname = "mw_cs2.create_material"
    bl_label = "Create MW CS2 PBR Material"
    bl_description = "Create and assign an independent CS2 authoring material"
    bl_options = {"REGISTER", "UNDO"}

    material_name: StringProperty(name="Material Name", default="")

    @classmethod
    def poll(cls, context):
        obj = getattr(context, "object", None)
        return bool(obj and getattr(getattr(obj, "data", None), "materials", None) is not None)

    def invoke(self, context, _event):
        self.material_name = suggested_material_name(context)
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, _context):
        self.layout.prop(self, "material_name")

    def execute(self, context):
        obj = context.object
        try:
            material = create_authoring_material(self.material_name)
            obj.data.materials.append(material)
            obj.active_material_index = len(obj.material_slots) - 1
        except Exception as exc:
            self.report({"ERROR"}, f"Could not create CS2 material: {exc}")
            return {"CANCELLED"}

        self.report({"INFO"}, f"Created and assigned {material.name}")
        return {"FINISHED"}


class MW_OT_load_texture(bpy.types.Operator):
    bl_idname = "mw_cs2.load_texture"
    bl_label = "Load CS2 Source Texture"
    bl_description = "Load a material-specific source texture"
    bl_options = {"REGISTER", "UNDO"}

    slot: EnumProperty(items=TEXTURE_SLOT_ITEMS)
    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.png;*.tif;*.tiff;*.exr;*.jpg;*.jpeg", options={"HIDDEN"})

    @classmethod
    def poll(cls, context):
        return is_mw_material(_active_material(context))

    @classmethod
    def description(cls, _context, properties):
        slot = getattr(properties, "slot", "BASE_COLOR")
        return f"Set {TEXTURE_SLOTS[slot]['map_name']} texture map"

    def invoke(self, context, _event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        material = _active_material(context)
        texture_node = find_texture_node(material, self.slot)
        if texture_node is None:
            self.report({"ERROR"}, "The selected CS2 texture slot is unavailable")
            return {"CANCELLED"}

        path = Path(self.filepath)
        if not path.is_file():
            self.report({"ERROR"}, "Select an existing texture image")
            return {"CANCELLED"}

        try:
            _load_file_into_slot(material, self.slot, path)
        except Exception as exc:
            self.report({"ERROR"}, f"Could not load texture: {exc}")
            return {"CANCELLED"}

        label = TEXTURE_SLOTS[self.slot]["label"]
        companions = (
            _auto_load_base_color_companions(material, path)
            if self.slot == "BASE_COLOR"
            else []
        )
        if companions:
            self.report(
                {"INFO"},
                f"Loaded {label} and {len(companions)} matching texture(s)",
            )
        else:
            self.report({"INFO"}, f"Loaded {label}: {path.name}")
        return {"FINISHED"}


class MW_OT_use_existing_image(bpy.types.Operator):
    bl_idname = "mw_cs2.use_existing_image"
    bl_label = "Use Existing Image"
    bl_description = "Choose an image already imported into this Blender file"
    bl_options = {"REGISTER", "UNDO"}

    slot: EnumProperty(items=TEXTURE_SLOT_ITEMS)
    image_name: EnumProperty(name="Image", items=_existing_image_items)

    @classmethod
    def poll(cls, context):
        return is_mw_material(_active_material(context))

    @classmethod
    def description(cls, _context, properties):
        slot = getattr(properties, "slot", "BASE_COLOR")
        return f"Use existing image for {TEXTURE_SLOTS[slot]['map_name']} texture map"

    def execute(self, context):
        if self.image_name == "__NONE__":
            self.report({"WARNING"}, "There are no imported images to select")
            return {"CANCELLED"}

        material = _active_material(context)
        texture_node = find_texture_node(material, self.slot)
        source = bpy.data.images.get(self.image_name)
        if texture_node is None or source is None:
            self.report({"ERROR"}, "The selected image is no longer available")
            return {"CANCELLED"}

        owner = f"{material.name}:{self.slot}"
        try:
            if source.filepath:
                preferred = _preferred_image_for_path(
                    Path(bpy.path.abspath(source.filepath)),
                    owner,
                )
                if preferred is not None:
                    source = preferred
            source_owner = source.get(IMAGE_MARKER)
            image = source if source_owner in (None, "", owner) else source.copy()
            if image is not source:
                image.name = f"{material.name} - {TEXTURE_SLOTS[self.slot]['label']}"
            _set_color_space(image, self.slot)
            image[IMAGE_MARKER] = owner
            texture_node.image = image
        except Exception as exc:
            self.report({"ERROR"}, f"Could not use existing image: {exc}")
            return {"CANCELLED"}

        self.report({"INFO"}, f"Using imported image {source.name}")
        if self.slot == "BASE_COLOR" and source.filepath:
            _auto_load_base_color_companions(
                material,
                Path(bpy.path.abspath(source.filepath)),
            )
        return {"FINISHED"}


class MW_OT_reload_all_textures(bpy.types.Operator):
    bl_idname = "mw_cs2.reload_all_textures"
    bl_label = "Reload All Textures"
    bl_description = "Reload all texture maps from disk"
    bl_options = {"REGISTER"}

    def execute(self, context):
        material = _active_material(context)
        reloaded = 0
        failures = []
        for slot, settings in TEXTURE_SLOTS.items():
            texture_node = find_texture_node(material, slot)
            if texture_node is None or texture_node.image is None:
                continue
            try:
                texture_node.image.reload()
                _set_color_space(texture_node.image, slot)
                reloaded += 1
            except Exception:
                failures.append(settings["label"])

        if failures:
            self.report({"WARNING"}, f"Reloaded {reloaded}; failed: {', '.join(failures)}")
        else:
            self.report({"INFO"}, f"Reloaded {reloaded} texture(s)")
        return {"FINISHED"}


class MW_OT_remove_all_textures(bpy.types.Operator):
    bl_idname = "mw_cs2.remove_all_textures"
    bl_label = "Remove All Textures"
    bl_description = "Remove all texture maps"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        material = _active_material(context)
        removed = 0
        for slot in TEXTURE_SLOTS:
            texture_node = find_texture_node(material, slot)
            if texture_node is not None and texture_node.image is not None:
                texture_node.image = None
                removed += 1
        set_texture_preview(material, "MATERIAL", context.scene)
        self.report({"INFO"}, f"Removed {removed} texture(s) from {material.name}")
        return {"FINISHED"}


class MW_OT_clear_texture(bpy.types.Operator):
    bl_idname = "mw_cs2.clear_texture"
    bl_label = "Clear Texture"
    bl_description = "Unlink this texture from the active material"
    bl_options = {"REGISTER", "UNDO"}

    slot: EnumProperty(items=TEXTURE_SLOT_ITEMS)

    @classmethod
    def description(cls, _context, properties):
        slot = getattr(properties, "slot", "BASE_COLOR")
        return f"Remove {TEXTURE_SLOTS[slot]['map_name']} texture map"

    def execute(self, context):
        material = _active_material(context)
        texture_node = find_texture_node(material, self.slot)
        if texture_node is None:
            return {"CANCELLED"}
        texture_node.image = None
        group_node = find_material_group_node(material)
        if group_node and group_node.node_tree.get(PREVIEW_SLOT_KEY) == self.slot:
            set_texture_preview(material, "MATERIAL", context.scene)
        return {"FINISHED"}


class MW_OT_reset_mask_color(bpy.types.Operator):
    bl_idname = "mw_cs2.reset_mask_color"
    bl_label = "Reset Mask Colour"
    bl_description = "Reset mask colour to white"
    bl_options = {"REGISTER", "UNDO"}

    mask_index: IntProperty(min=1, max=3)

    def execute(self, context):
        group_node = find_material_group_node(_active_material(context))
        if group_node is None:
            return {"CANCELLED"}
        group_node.inputs[f"CM{self.mask_index} Colour"].default_value = (
            1.0,
            1.0,
            1.0,
            1.0,
        )
        return {"FINISHED"}


class MW_OT_preview_texture(bpy.types.Operator):
    bl_idname = "mw_cs2.preview_texture"
    bl_label = "Preview Texture"
    bl_description = "Show this source texture directly on the model"
    bl_options = {"REGISTER", "UNDO"}

    slot: EnumProperty(items=PREVIEW_SLOT_ITEMS)

    @classmethod
    def description(cls, _context, properties):
        slot = getattr(properties, "slot", "MATERIAL")
        if slot == "MATERIAL":
            return "Show complete material"
        return "Use Emit Bake Type for direct texture baking."

    def execute(self, context):
        material = _active_material(context)
        if not set_texture_preview(material, self.slot, context.scene):
            self.report({"ERROR"}, "Could not change the material preview")
            return {"CANCELLED"}
        label = "complete material" if self.slot == "MATERIAL" else TEXTURE_SLOTS[self.slot]["label"]
        self.report({"INFO"}, f"Previewing {label}")
        return {"FINISHED"}


class MW_OT_export_textures(bpy.types.Operator):
    bl_idname = "mw_cs2.export_textures"
    bl_label = "Export CS2 Texture Set"
    bl_description = "Export five CS2 texture maps"
    bl_options = {"REGISTER"}

    directory: StringProperty(name="Export Folder", subtype="DIR_PATH")
    asset_name: StringProperty(
        name="Asset Name",
        description="Case-sensitive filename prefix matching the CS2 mesh name",
    )

    def invoke(self, context, _event):
        obj = getattr(context, "object", None)
        material = _active_material(context)
        if not self.asset_name:
            self.asset_name = obj.name if obj is not None else material.name
        if not self.directory:
            base_node = find_texture_node(material, "BASE_COLOR")
            if base_node and base_node.image and base_node.image.filepath:
                self.directory = str(Path(bpy.path.abspath(base_node.image.filepath)).parent)
            elif bpy.data.filepath:
                self.directory = str(Path(bpy.data.filepath).parent)
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        try:
            paths, warnings = export_cs2_texture_set(
                _active_material(context),
                self.directory,
                self.asset_name,
                context.scene,
            )
        except (CS2ExportError, OSError, RuntimeError) as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}

        if warnings:
            self.report({"WARNING"}, "; ".join(warnings))
        else:
            self.report({"INFO"}, f"Exported {len(paths)} CS2 textures")
        return {"FINISHED"}


class MW_OT_ui_hint(bpy.types.Operator):
    bl_idname = "mw_cs2.ui_hint"
    bl_label = "MW CS2 Information"
    bl_options = {"INTERNAL"}

    topic: EnumProperty(
        items=(
            ("BASE_COLOR", "Base Color", "Base Color automatic loading information"),
            ("BAKE_PREVIEW", "Bake Previews", "Bake preview information"),
        )
    )

    @classmethod
    def description(cls, _context, properties):
        if getattr(properties, "topic", "") == "BASE_COLOR":
            return "Load BaseColor and matching texture maps"
        if getattr(properties, "topic", "") == "BAKE_PREVIEW":
            return "Use Emit Bake Type for direct texture baking."
        return "MW CS2 material information"

    def execute(self, _context):
        return {"FINISHED"}


classes = (
    MW_OT_create_material,
    MW_OT_load_texture,
    MW_OT_use_existing_image,
    MW_OT_reload_all_textures,
    MW_OT_remove_all_textures,
    MW_OT_clear_texture,
    MW_OT_reset_mask_color,
    MW_OT_preview_texture,
    MW_OT_export_textures,
    MW_OT_ui_hint,
)
