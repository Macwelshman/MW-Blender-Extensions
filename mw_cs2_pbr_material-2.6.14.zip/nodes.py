from __future__ import annotations

from array import array
from pathlib import Path

import bpy

from .constants import (
    GROUP_NODE_MARKER,
    GROUP_NODE_NAME,
    MATERIAL_MARKER,
    MATERIAL_RELOAD_BACKUP_KEY,
    MATERIAL_SCHEMA_KEY,
    MATERIAL_SCHEMA_VERSION,
    PREVIEW_NODE_NAME,
    PREVIEW_SLOT_KEY,
    PREVIEW_VIEW_TRANSFORM_KEY,
    PRINCIPLED_NODE_NAME,
    TEXTURE_SLOTS,
)


_RELOAD_SOCKET_NAMES = (
    "CM1 Colour",
    "CM2 Colour",
    "CM3 Colour",
    "Emission Strength",
)


def _srgb_channel_to_linear(value):
    return value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4


def set_image_color_space(image: bpy.types.Image, target: str) -> None:
    if image.colorspace_settings.name == target:
        return

    preserved_pixels = None
    if image.source == "GENERATED":
        preserved_pixels = array("f", [0.0]) * len(image.pixels)
        image.pixels.foreach_get(preserved_pixels)

    image.colorspace_settings.name = target
    if preserved_pixels is not None:
        image.pixels.foreach_set(preserved_pixels)
        image.update()


def restore_preview_view_transform(scene: bpy.types.Scene | None) -> None:
    if scene is None or PREVIEW_VIEW_TRANSFORM_KEY not in scene:
        return
    previous = scene.get(PREVIEW_VIEW_TRANSFORM_KEY)
    if previous:
        try:
            scene.view_settings.view_transform = previous
        except TypeError:
            pass
    del scene[PREVIEW_VIEW_TRANSFORM_KEY]


def is_mw_material(material: bpy.types.Material | None) -> bool:
    if material is None:
        return False
    if material.get(MATERIAL_MARKER):
        return True
    return _find_structural_group_node(material) is not None


def _looks_like_authoring_group(tree: bpy.types.ShaderNodeTree | None) -> bool:
    """Recognise groups created by this add-on without relying on ID markers."""
    if tree is None:
        return False
    required_nodes = (
        "MW Material Controls",
        "MW Shader Output",
        PRINCIPLED_NODE_NAME,
        TEXTURE_SLOTS["BASE_COLOR"]["node"],
        TEXTURE_SLOTS["COLOR_MASK_1"]["node"],
    )
    return all(tree.nodes.get(name) is not None for name in required_nodes)


def _find_structural_group_node(
    material: bpy.types.Material | None,
) -> bpy.types.ShaderNodeGroup | None:
    if material is None or material.node_tree is None:
        return None
    for node in material.node_tree.nodes:
        if node.type == "GROUP" and _looks_like_authoring_group(node.node_tree):
            return node
    return None


def find_material_group_node(
    material: bpy.types.Material | None,
) -> bpy.types.ShaderNodeGroup | None:
    if material is None or material.node_tree is None:
        return None
    for node in material.node_tree.nodes:
        if node.type == "GROUP" and node.get(GROUP_NODE_MARKER):
            return node
    return _find_structural_group_node(material)


def find_texture_node(
    material: bpy.types.Material | None, slot: str
) -> bpy.types.ShaderNodeTexImage | None:
    settings = TEXTURE_SLOTS.get(slot)
    group_node = find_material_group_node(material)
    if settings is None or group_node is None or group_node.node_tree is None:
        return None
    node = group_node.node_tree.nodes.get(settings["node"])
    return node if node and node.type == "TEX_IMAGE" else None


def _find_interface_input(tree: bpy.types.ShaderNodeTree, name: str):
    for item in tree.interface.items_tree:
        if (
            getattr(item, "item_type", "") == "SOCKET"
            and getattr(item, "in_out", "") == "INPUT"
            and item.name == name
        ):
            return item
    return None


def _ensure_input_link(tree, output_socket, input_socket) -> bool:
    """Connect an owned shader input exactly once, repairing stale links."""
    if output_socket is None or input_socket is None:
        return False
    if (
        len(input_socket.links) == 1
        and input_socket.links[0].from_socket == output_socket
    ):
        return False
    for link in tuple(input_socket.links):
        tree.links.remove(link)
    tree.links.new(output_socket, input_socket)
    return True


def _repair_surface_links(tree: bpy.types.ShaderNodeTree) -> bool:
    """Restore roughness and tangent normals across the base and coat lobes."""
    principled = tree.nodes.get(PRINCIPLED_NODE_NAME)
    roughness = tree.nodes.get(TEXTURE_SLOTS["ROUGHNESS"]["node"])
    normal_texture = tree.nodes.get(TEXTURE_SLOTS["NORMAL"]["node"])
    normal_map = tree.nodes.get("MW OpenGL Normal Map")
    if principled is None or roughness is None or normal_texture is None:
        return False

    repaired = _ensure_input_link(
        tree,
        roughness.outputs.get("Color"),
        principled.inputs.get("Roughness"),
    )
    repaired |= _ensure_input_link(
        tree,
        roughness.outputs.get("Color"),
        principled.inputs.get("Coat Roughness"),
    )
    if normal_map is not None:
        repaired |= _ensure_input_link(
            tree,
            normal_texture.outputs.get("Color"),
            normal_map.inputs.get("Color"),
        )
        repaired |= _ensure_input_link(
            tree,
            normal_map.outputs.get("Normal"),
            principled.inputs.get("Normal"),
        )
        repaired |= _ensure_input_link(
            tree,
            normal_map.outputs.get("Normal"),
            principled.inputs.get("Coat Normal"),
        )
        for link in tuple(normal_map.inputs["Strength"].links):
            tree.links.remove(link)
            repaired = True
        if normal_map.inputs["Strength"].default_value != 1.0:
            normal_map.inputs["Strength"].default_value = 1.0
            repaired = True
    opacity = tree.nodes.get(TEXTURE_SLOTS["OPACITY"]["node"])
    if opacity is not None:
        repaired |= _ensure_input_link(
            tree,
            opacity.outputs.get("Color"),
            principled.inputs.get("Alpha"),
        )
    return repaired


def snapshot_authoring_material(material: bpy.types.Material | None) -> bool:
    """Store a short-lived copy of UI state before Blender reloads the add-on."""
    group_node = find_material_group_node(material)
    if group_node is None or group_node.node_tree is None:
        return False

    socket_values = {}
    for name in _RELOAD_SOCKET_NAMES:
        socket = group_node.inputs.get(name)
        if socket is None:
            continue
        value = socket.default_value
        socket_values[name] = list(value) if hasattr(value, "__len__") else value

    images = {}
    for slot in TEXTURE_SLOTS:
        texture_node = find_texture_node(material, slot)
        if texture_node is not None and texture_node.image is not None:
            images[slot] = texture_node.image.name

    material[MATERIAL_RELOAD_BACKUP_KEY] = {
        "sockets": socket_values,
        "images": images,
        "backface_culling": bool(material.use_backface_culling),
        "preview": group_node.node_tree.get(PREVIEW_SLOT_KEY, "MATERIAL"),
        "export_directory": getattr(material, "mw_cs2_export_directory", ""),
        "export_name": getattr(material, "mw_cs2_export_name", ""),
    }
    return True


def restore_authoring_material(material: bpy.types.Material | None) -> bool:
    """Restore and remove reload state once the add-on is registered again."""
    if material is None or MATERIAL_RELOAD_BACKUP_KEY not in material:
        return False
    group_node = find_material_group_node(material)
    if group_node is None or group_node.node_tree is None:
        return False

    backup = material[MATERIAL_RELOAD_BACKUP_KEY]
    for name, value in backup.get("sockets", {}).items():
        socket = group_node.inputs.get(name)
        if socket is not None:
            socket.default_value = value

    for slot, image_name in backup.get("images", {}).items():
        texture_node = find_texture_node(material, slot)
        image = bpy.data.images.get(image_name)
        if texture_node is not None and image is not None:
            texture_node.image = image

    material.use_backface_culling = bool(backup.get("backface_culling", False))
    group_node.node_tree[PREVIEW_SLOT_KEY] = backup.get("preview", "MATERIAL")
    if hasattr(material, "mw_cs2_export_directory"):
        material.mw_cs2_export_directory = backup.get("export_directory", "")
    if hasattr(material, "mw_cs2_export_name"):
        material.mw_cs2_export_name = backup.get("export_name", "")
    del material[MATERIAL_RELOAD_BACKUP_KEY]
    return True


def migrate_authoring_material(material: bpy.types.Material | None) -> bool:
    if not is_mw_material(material):
        return False

    restored = restore_authoring_material(material)

    group_node = find_material_group_node(material)
    if group_node is None or group_node.node_tree is None:
        return restored
    identity_repaired = False
    if not material.get(MATERIAL_MARKER):
        try:
            material[MATERIAL_MARKER] = True
            identity_repaired = True
        except (AttributeError, RuntimeError, TypeError):
            pass
    if not group_node.get(GROUP_NODE_MARKER):
        try:
            group_node[GROUP_NODE_MARKER] = True
            identity_repaired = True
        except (AttributeError, RuntimeError, TypeError):
            pass
    tree = group_node.node_tree

    repaired = _repair_surface_links(tree)

    # Colour space is part of the Image datablock, not the texture node. An
    # older direct-preview implementation temporarily changed normal images to
    # sRGB, which could leave the actual shader decoding tangent normals as
    # colour data. Repair every assigned source before the schema early return.
    for slot, settings in TEXTURE_SLOTS.items():
        texture_node = find_texture_node(material, slot)
        if texture_node is not None and texture_node.image is not None:
            try:
                set_image_color_space(texture_node.image, settings["color_space"])
            except (TypeError, ValueError):
                pass

    if material.get(MATERIAL_SCHEMA_KEY, 0) >= MATERIAL_SCHEMA_VERSION:
        if repaired:
            tree.update_tag()
        return restored or identity_repaired or repaired

    old_culling_socket = group_node.inputs.get("Backface Culling")
    old_culling_interface = _find_interface_input(tree, "Backface Culling")
    if old_culling_socket is not None:
        material.use_backface_culling = bool(old_culling_socket.default_value)
    if old_culling_interface is not None:
        tree.interface.remove(old_culling_interface)

    texture_coordinates = tree.nodes.get("MW Texture Coordinates")
    texture_scale = tree.nodes.get("MW Texture Scale")
    if texture_coordinates is not None:
        for slot in TEXTURE_SLOTS:
            texture_node = find_texture_node(material, slot)
            if texture_node is not None:
                _ensure_input_link(
                    tree,
                    texture_coordinates.outputs.get("UV"),
                    texture_node.inputs.get("Vector"),
                )
    if texture_scale is not None:
        tree.nodes.remove(texture_scale)

    opacity_switch = tree.nodes.get("MW Opacity Switch")
    if opacity_switch is not None:
        tree.nodes.remove(opacity_switch)

    coordinate_switch = tree.nodes.get("MW Coordinate Switch")
    if coordinate_switch is not None:
        tree.nodes.remove(coordinate_switch)

    for name in (
        "Use UV Coordinates",
        "Use Object Coordinates",
        "Uses Opacity",
        "Normal Strength",
        "Texture Scale",
    ):
        interface_socket = _find_interface_input(tree, name)
        if interface_socket is not None:
            tree.interface.remove(interface_socket)

    emission_interface = _find_interface_input(tree, "Emission Strength")
    if emission_interface is not None:
        emission_interface.max_value = 10.0
    emission_socket = group_node.inputs.get("Emission Strength")
    if emission_socket is not None and emission_socket.default_value > 10.0:
        emission_socket.default_value = 10.0

    repaired |= _repair_surface_links(tree)

    material[MATERIAL_SCHEMA_KEY] = MATERIAL_SCHEMA_VERSION
    tree[MATERIAL_SCHEMA_KEY] = MATERIAL_SCHEMA_VERSION
    tree.update_tag()
    return True


def snapshot_all_materials() -> int:
    saved = 0
    for material in getattr(bpy.data, "materials", ()):
        if snapshot_authoring_material(material):
            saved += 1
    return saved


def migrate_all_materials() -> int:
    migrated = 0
    # Blender restricts bpy.data while an extension's register() is running.
    # The load handler and panel-level migration will retry once data is available.
    for material in getattr(bpy.data, "materials", ()):
        if migrate_authoring_material(material):
            migrated += 1
    return migrated


def set_texture_preview(
    material: bpy.types.Material | None,
    slot: str,
    scene: bpy.types.Scene | None = None,
) -> bool:
    group_node = find_material_group_node(material)
    if group_node is None or group_node.node_tree is None:
        return False

    tree = group_node.node_tree
    output_node = tree.nodes.get("MW Shader Output")
    principled = tree.nodes.get(PRINCIPLED_NODE_NAME)
    preview = tree.nodes.get(PREVIEW_NODE_NAME)
    if output_node is None or principled is None or preview is None:
        return False

    # Previewing a texture must never alter scene colour management. Restore
    # state left by versions that temporarily switched the whole scene to
    # Standard for normal-map display.
    restore_preview_view_transform(scene)

    obsolete_gamma = tree.nodes.get("MW Normal Preview sRGB")
    if obsolete_gamma is not None and obsolete_gamma.bl_idname == "ShaderNodeGamma":
        tree.nodes.remove(obsolete_gamma)

    normal_texture = find_texture_node(material, "NORMAL")
    if normal_texture is not None and normal_texture.image is not None:
        set_image_color_space(normal_texture.image, "Non-Color")

    output_socket = output_node.inputs.get("Shader")
    for link in tuple(output_socket.links):
        tree.links.remove(link)

    if slot == "MATERIAL":
        tree.links.new(principled.outputs["BSDF"], output_socket)
    else:
        texture_node = find_texture_node(material, slot)
        if texture_node is None:
            return False
        preview_color = preview.inputs["Color"]
        for link in tuple(preview_color.links):
            tree.links.remove(link)
        if texture_node.image is None:
            fallback = TEXTURE_SLOTS[slot]["default"]
            if slot == "NORMAL":
                fallback = tuple(
                    _srgb_channel_to_linear(value) for value in fallback[:3]
                ) + (fallback[3],)
            preview_color.default_value = fallback
        else:
            tree.links.new(texture_node.outputs["Color"], preview_color)
        tree.links.new(preview.outputs["Emission"], output_socket)

    tree[PREVIEW_SLOT_KEY] = slot
    return True


def suggested_material_name(context: bpy.types.Context) -> str:
    if bpy.data.filepath:
        return Path(bpy.data.filepath).stem
    active_object = getattr(context, "object", None)
    if active_object is not None and active_object.name:
        return f"{active_object.name} CS2"
    return "MW CS2 PBR Material"


def _new_interface_socket(
    tree: bpy.types.ShaderNodeTree,
    name: str,
    socket_type: str,
    *,
    in_out: str = "INPUT",
    parent: bpy.types.NodeTreeInterfacePanel | None = None,
    default=None,
    minimum: float | None = None,
    maximum: float | None = None,
    description: str = "",
):
    socket = tree.interface.new_socket(
        name=name,
        in_out=in_out,
        socket_type=socket_type,
        parent=parent,
    )
    if default is not None:
        socket.default_value = default
    if minimum is not None:
        socket.min_value = minimum
    if maximum is not None:
        socket.max_value = maximum
    socket.description = description
    return socket


def _make_frame(tree, name, label, location, color):
    frame = tree.nodes.new("NodeFrame")
    frame.name = name
    frame.label = label
    frame.location = location
    frame.use_custom_color = True
    frame.color = color
    frame.label_size = 22
    frame.shrink = True
    return frame


def _make_image_node(tree, slot, parent, location):
    settings = TEXTURE_SLOTS[slot]
    node = tree.nodes.new("ShaderNodeTexImage")
    node.name = settings["node"]
    node.label = settings["label"]
    node.parent = parent
    node.location = location
    node.width = 230
    node.interpolation = "Linear"
    node.extension = "REPEAT"
    node.projection = "FLAT"
    node.outputs["Color"].default_value = settings["default"]
    return node


def _make_mix_rgb(tree, name, label, blend_type, parent, location):
    node = tree.nodes.new("ShaderNodeMixRGB")
    node.name = name
    node.label = label
    node.blend_type = blend_type
    node.parent = parent
    node.location = location
    node.width = 190
    node.use_clamp = False
    return node


def build_authoring_group(name: str) -> bpy.types.ShaderNodeTree:
    tree = bpy.data.node_groups.new(name=name, type="ShaderNodeTree")
    tree.color_tag = "SHADER"
    tree.description = "Clean, material-specific CS2 authoring and preview shader"
    tree[MATERIAL_SCHEMA_KEY] = MATERIAL_SCHEMA_VERSION

    _new_interface_socket(
        tree,
        "Shader",
        "NodeSocketShader",
        in_out="OUTPUT",
        description="Connect to the material Surface input",
    )
    masks_panel = tree.interface.new_panel("Colour Masks", default_closed=True)
    for index in range(1, 4):
        _new_interface_socket(
            tree,
            f"CM{index} Colour",
            "NodeSocketColor",
            parent=masks_panel,
            default=(1.0, 1.0, 1.0, 1.0),
            description=f"Preview colour applied by Colour Mask {index}",
        )

    emission_panel = tree.interface.new_panel("Emission", default_closed=True)
    _new_interface_socket(
        tree,
        "Emission Strength",
        "NodeSocketFloat",
        parent=emission_panel,
        default=0.0,
        minimum=0.0,
        maximum=10.0,
        description="Preview emission strength",
    )

    nodes = tree.nodes
    links = tree.links

    input_node = nodes.new("NodeGroupInput")
    input_node.name = "MW Material Controls"
    input_node.label = "Material Controls"
    input_node.location = (-1450, 760)
    input_node.width = 220

    output_node = nodes.new("NodeGroupOutput")
    output_node.name = "MW Shader Output"
    output_node.label = "Shader Output"
    output_node.location = (850, 120)
    output_node.width = 180

    coordinates_frame = _make_frame(
        tree,
        "MW Frame - Coordinates",
        "1. Texture Coordinates",
        (-1280, 200),
        (0.12, 0.22, 0.32),
    )
    textures_frame = _make_frame(
        tree,
        "MW Frame - Textures",
        "2. Source Textures",
        (-900, 200),
        (0.12, 0.30, 0.18),
    )
    masks_frame = _make_frame(
        tree,
        "MW Frame - Masks",
        "3. Colour Mask Preview",
        (-460, 500),
        (0.32, 0.22, 0.08),
    )
    surface_frame = _make_frame(
        tree,
        "MW Frame - Surface",
        "4. Surface Processing",
        (-460, -250),
        (0.25, 0.16, 0.30),
    )
    shader_frame = _make_frame(
        tree,
        "MW Frame - Shader",
        "5. Final Shader",
        (170, 120),
        (0.28, 0.14, 0.14),
    )

    tex_coord = nodes.new("ShaderNodeTexCoord")
    tex_coord.name = "MW Texture Coordinates"
    tex_coord.parent = coordinates_frame
    tex_coord.location = (0, 100)
    tex_coord.width = 180

    texture_order = (
        "BASE_COLOR",
        "ROUGHNESS",
        "NORMAL",
        "METALLIC",
        "OPACITY",
        "EMISSION",
        "COLOR_MASK_1",
        "COLOR_MASK_2",
        "COLOR_MASK_3",
        "COAT",
        "SNOW_REMOVE",
    )
    texture_nodes = {}
    for index, slot in enumerate(texture_order):
        texture_node = _make_image_node(
            tree,
            slot,
            textures_frame,
            (0, 720 - index * 250),
        )
        texture_nodes[slot] = texture_node
        links.new(tex_coord.outputs["UV"], texture_node.inputs["Vector"])

    mask_mixes = []
    previous_color = texture_nodes["BASE_COLOR"].outputs["Color"]
    for index in range(1, 4):
        mix = _make_mix_rgb(
            tree,
            f"MW Colour Mask Mix {index}",
            f"Apply Colour Mask {index}",
            "MULTIPLY",
            masks_frame,
            (0, 520 - index * 210),
        )
        links.new(texture_nodes[f"COLOR_MASK_{index}"].outputs["Color"], mix.inputs["Fac"])
        links.new(previous_color, mix.inputs[1])
        links.new(input_node.outputs[f"CM{index} Colour"], mix.inputs[2])
        previous_color = mix.outputs["Color"]
        mask_mixes.append(mix)

    normal_map = nodes.new("ShaderNodeNormalMap")
    normal_map.name = "MW OpenGL Normal Map"
    normal_map.label = "OpenGL Normal Map"
    normal_map.space = "TANGENT"
    normal_map.parent = surface_frame
    normal_map.location = (0, 230)
    normal_map.width = 200
    normal_map.inputs["Strength"].default_value = 1.0
    links.new(texture_nodes["NORMAL"].outputs["Color"], normal_map.inputs["Color"])

    principled = nodes.new("ShaderNodeBsdfPrincipled")
    principled.name = PRINCIPLED_NODE_NAME
    principled.label = "CS2 Authoring Preview"
    principled.parent = shader_frame
    principled.location = (0, 100)
    principled.width = 260
    principled.inputs["IOR"].default_value = 1.45
    principled.inputs["Specular IOR Level"].default_value = 0.4

    links.new(previous_color, principled.inputs["Base Color"])
    links.new(texture_nodes["ROUGHNESS"].outputs["Color"], principled.inputs["Roughness"])
    links.new(texture_nodes["METALLIC"].outputs["Color"], principled.inputs["Metallic"])
    links.new(texture_nodes["COAT"].outputs["Color"], principled.inputs["Coat Weight"])
    links.new(normal_map.outputs["Normal"], principled.inputs["Normal"])
    links.new(normal_map.outputs["Normal"], principled.inputs["Coat Normal"])
    links.new(texture_nodes["ROUGHNESS"].outputs["Color"], principled.inputs["Coat Roughness"])
    links.new(texture_nodes["OPACITY"].outputs["Color"], principled.inputs["Alpha"])
    links.new(texture_nodes["EMISSION"].outputs["Color"], principled.inputs["Emission Color"])
    links.new(input_node.outputs["Emission Strength"], principled.inputs["Emission Strength"])

    preview = nodes.new("ShaderNodeEmission")
    preview.name = PREVIEW_NODE_NAME
    preview.label = "Direct Texture Preview"
    preview.parent = shader_frame
    preview.location = (0, -260)
    preview.width = 220
    preview.inputs["Strength"].default_value = 1.0

    links.new(principled.outputs["BSDF"], output_node.inputs["Shader"])
    tree[PREVIEW_SLOT_KEY] = "MATERIAL"

    return tree


def create_authoring_material(name: str) -> bpy.types.Material:
    material = None
    group = None
    try:
        material = bpy.data.materials.new(name=name.strip() or "MW CS2 PBR Material")
        material.use_nodes = True
        material[MATERIAL_MARKER] = True
        material[MATERIAL_SCHEMA_KEY] = MATERIAL_SCHEMA_VERSION
        material.use_backface_culling = False

        if hasattr(material, "surface_render_method"):
            material.surface_render_method = "DITHERED"
        if hasattr(material, "use_transparency_overlap"):
            material.use_transparency_overlap = True
        if hasattr(material, "use_transparent_shadow"):
            material.use_transparent_shadow = True

        group = build_authoring_group(f"MW CS2 PBR - {material.name}")

        tree = material.node_tree
        tree.nodes.clear()

        group_node = tree.nodes.new("ShaderNodeGroup")
        group_node.name = GROUP_NODE_NAME
        group_node.label = material.name
        group_node.node_tree = group
        group_node.location = (-260, 0)
        group_node.width = 240
        group_node[GROUP_NODE_MARKER] = True

        output = tree.nodes.new("ShaderNodeOutputMaterial")
        output.name = "Material Output"
        output.location = (100, 0)
        output.is_active_output = True
        tree.links.new(group_node.outputs["Shader"], output.inputs["Surface"])

        return material
    except Exception:
        if material is not None:
            bpy.data.materials.remove(material, do_unlink=True)
        if group is not None and group.name in bpy.data.node_groups:
            bpy.data.node_groups.remove(group, do_unlink=True)
        raise
