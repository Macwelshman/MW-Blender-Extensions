bl_info = {
    "name": "MW CS2 PBR Material",
    "author": "Macwelshman",
    "version": (2, 6, 14),
    "blender": (5, 0, 0),
    "location": "Material Properties > MW CS2 PBR Material",
    "description": "Create clean, independent CS2 authoring materials",
    "category": "Material",
}

import bpy
from bpy.app.handlers import persistent
from bpy.props import StringProperty

from .nodes import (
    migrate_all_materials,
    restore_preview_view_transform,
    snapshot_all_materials,
)
from .operators import classes as operator_classes
from .panels import _draw_material_interface, classes as panel_classes


classes = operator_classes + panel_classes
MATERIAL_CONTEXT_PANELS = (
    "EEVEE_MATERIAL_PT_context_material",
    "CYCLES_PT_context_material",
)


def _remove_material_context_draw_callbacks(panel):
    """Remove callbacks left behind by this add-on, including stale reloads."""
    draw_functions = tuple(getattr(panel.draw, "_draw_funcs", ()))
    for callback in draw_functions:
        callback_module = getattr(callback, "__module__", "")
        if (
            getattr(callback, "__name__", "") == "_material_context_draw"
            and callback_module.endswith("mw_cs2_pbr_material")
        ):
            try:
                panel.remove(callback)
            except ValueError:
                pass


def _register_material_context_draw():
    for panel_name in MATERIAL_CONTEXT_PANELS:
        panel = getattr(bpy.types, panel_name, None)
        if panel is not None:
            _remove_material_context_draw_callbacks(panel)
            panel.append(_material_context_draw)


@persistent
def _migrate_loaded_materials(_unused):
    migrate_all_materials()


def _shader_add_menu(self, context):
    space = getattr(context, "space_data", None)
    if getattr(space, "tree_type", "") != "ShaderNodeTree":
        return
    self.layout.separator()
    self.layout.operator("mw_cs2.create_material", icon="MATERIAL")


def _material_context_draw(self, context):
    obj = getattr(context, "object", None)
    if obj is None or getattr(getattr(obj, "data", None), "materials", None) is None:
        return

    self.layout.separator()
    create = self.layout.operator(
        "mw_cs2.create_material",
        text="Create CS2 PBR Material",
        icon="ADD",
    )
    create.material_name = ""
    _draw_material_interface(self.layout, context)


def register():
    bpy.types.Material.mw_cs2_export_directory = StringProperty(
        name="Export Folder",
        description="Destination folder for the five CS2 texture PNG files",
        subtype="DIR_PATH",
    )
    bpy.types.Material.mw_cs2_export_name = StringProperty(
        name="Asset Name",
        description="Optional filename prefix; the selected object name is used when empty",
    )
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.NODE_MT_add.append(_shader_add_menu)
    _register_material_context_draw()
    if _migrate_loaded_materials not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_migrate_loaded_materials)
    # Older normal previews temporarily changed the scene view transform.
    # Recover that state before repairing loaded authoring materials.
    for scene in getattr(bpy.data, "scenes", ()):
        restore_preview_view_transform(scene)
    migrate_all_materials()


def unregister():
    snapshot_all_materials()
    for scene in getattr(bpy.data, "scenes", ()):
        restore_preview_view_transform(scene)
    if _migrate_loaded_materials in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_migrate_loaded_materials)
    for panel_name in reversed(MATERIAL_CONTEXT_PANELS):
        panel = getattr(bpy.types, panel_name, None)
        if panel is not None:
            _remove_material_context_draw_callbacks(panel)
    bpy.types.NODE_MT_add.remove(_shader_add_menu)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    if hasattr(bpy.types.Material, "mw_cs2_export_name"):
        del bpy.types.Material.mw_cs2_export_name
    if hasattr(bpy.types.Material, "mw_cs2_export_directory"):
        del bpy.types.Material.mw_cs2_export_directory
