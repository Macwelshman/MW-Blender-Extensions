from __future__ import annotations

from pathlib import Path

import bpy
import numpy as np

from .constants import PREVIEW_SLOT_KEY, TEXTURE_SLOTS
from .nodes import (
    find_material_group_node,
    find_texture_node,
    is_mw_material,
    set_texture_preview,
)


class CS2ExportError(RuntimeError):
    pass


def _safe_asset_name(name: str) -> str:
    cleaned = name.strip()
    if cleaned.lower().endswith(".fbx"):
        cleaned = cleaned[:-4]
    for character in '<>:"/\\|?*':
        cleaned = cleaned.replace(character, "_")
    return cleaned.strip(". ")


def _slot_pixels(material, slot, width, height):
    texture_node = find_texture_node(material, slot)
    image = texture_node.image if texture_node is not None else None
    if image is None:
        default = np.asarray(TEXTURE_SLOTS[slot]["default"], dtype=np.float32)
        return np.broadcast_to(default, (width * height, 4)).copy()

    if tuple(image.size) != (width, height):
        raise CS2ExportError(
            f"{TEXTURE_SLOTS[slot]['label']} must be {width}×{height} to match BaseColor. "
            "Textures are never resized"
        )

    pixels = np.empty(width * height * 4, dtype=np.float32)
    image.pixels.foreach_get(pixels)
    return pixels.reshape((-1, 4))


def _validate_source_dimensions(material, width, height):
    mismatches = []
    for slot, settings in TEXTURE_SLOTS.items():
        texture_node = find_texture_node(material, slot)
        image = texture_node.image if texture_node is not None else None
        if image is not None and tuple(image.size) != (width, height):
            mismatches.append(
                f"{settings['label']} ({image.size[0]}×{image.size[1]})"
            )
    if mismatches:
        raise CS2ExportError(
            f"All source textures must match BaseColor ({width}×{height}): "
            + ", ".join(mismatches)
            + ". Textures are never resized"
        )


def _write_png(path, width, height, pixels, color_space):
    image = bpy.data.images.new(
        name=f"MW CS2 Export - {path.name}",
        width=width,
        height=height,
        alpha=True,
        float_buffer=False,
    )
    try:
        image.colorspace_settings.name = color_space
        image.alpha_mode = "STRAIGHT"
        image.file_format = "PNG"
        image.filepath_raw = str(path)
        image.pixels.foreach_set(np.ascontiguousarray(pixels, dtype=np.float32).ravel())
        image.update()
        image.save()
    finally:
        bpy.data.images.remove(image)


def export_cs2_texture_set(material, directory, asset_name, scene=None):
    if not is_mw_material(material):
        raise CS2ExportError("The active material is not an MW CS2 material")

    group_node = find_material_group_node(material)
    if group_node is None or group_node.node_tree is None:
        raise CS2ExportError("The MW material group is missing")

    base_node = find_texture_node(material, "BASE_COLOR")
    if base_node is None or base_node.image is None:
        raise CS2ExportError("Load a Base Color texture before exporting")

    width, height = base_node.image.size
    if width <= 0 or height <= 0:
        raise CS2ExportError("The Base Color image has no pixel data")
    if width != height:
        raise CS2ExportError("CS2 textures must be square (1:1)")
    _validate_source_dimensions(material, width, height)

    prefix = _safe_asset_name(asset_name)
    if not prefix:
        raise CS2ExportError("Enter a valid CS2 asset name")

    output_directory = Path(bpy.path.abspath(str(directory))).expanduser()
    output_directory.mkdir(parents=True, exist_ok=True)
    paths = {
        suffix: output_directory / f"{prefix}_{suffix}.png"
        for suffix in ("BaseColor", "ControlMask", "MaskMap", "Normal", "Emissive")
    }

    previous_preview = group_node.node_tree.get(PREVIEW_SLOT_KEY, "MATERIAL")
    set_texture_preview(material, "MATERIAL", scene)
    try:
        base = _slot_pixels(material, "BASE_COLOR", width, height)
        opacity_node = find_texture_node(material, "OPACITY")
        if opacity_node is not None and opacity_node.image is not None:
            opacity = _slot_pixels(material, "OPACITY", width, height)
            base[:, 3] = opacity[:, 0]
        else:
            base[:, 3] = 1.0
        _write_png(paths["BaseColor"], width, height, base, "sRGB")
        del base

        control = np.zeros((width * height, 4), dtype=np.float32)
        for channel, slot in enumerate(("COLOR_MASK_1", "COLOR_MASK_2", "COLOR_MASK_3")):
            source = _slot_pixels(material, slot, width, height)
            control[:, channel] = source[:, 0]
            del source
        snow = _slot_pixels(material, "SNOW_REMOVE", width, height)
        control[:, 3] = snow[:, 0]
        del snow
        _write_png(paths["ControlMask"], width, height, control, "Non-Color")
        del control

        mask = np.zeros((width * height, 4), dtype=np.float32)
        metallic = _slot_pixels(material, "METALLIC", width, height)
        mask[:, 0] = metallic[:, 0]
        del metallic
        coat = _slot_pixels(material, "COAT", width, height)
        mask[:, 1] = coat[:, 0]
        del coat
        roughness = _slot_pixels(material, "ROUGHNESS", width, height)
        mask[:, 3] = 1.0 - roughness[:, 0]
        del roughness
        _write_png(paths["MaskMap"], width, height, np.clip(mask, 0.0, 1.0), "Non-Color")
        del mask

        normal = _slot_pixels(material, "NORMAL", width, height)
        normal[:, 3] = 1.0
        _write_png(paths["Normal"], width, height, normal, "Non-Color")
        del normal

        emissive = _slot_pixels(material, "EMISSION", width, height)
        emissive[:, 3] = 1.0
        _write_png(paths["Emissive"], width, height, emissive, "sRGB")
        del emissive
    finally:
        set_texture_preview(material, previous_preview, scene)

    warnings = []
    if width < 512:
        warnings.append(f"{width}×{height} is below the recommended 512×512 minimum")
    return tuple(paths.values()), tuple(warnings)
